# stockpile
4th semsester Database project
# rules : Don't commit as master , commit using ur name. and pull from master first.

Statement:
    An online marketing system in which user is presented with a market portal which has the ability to let user view the items, get registered and buy item/s. admin team manages the inventory and process the user buy request.
    
    Objectives:
    -- a dynamic website which can show products.
    -- b user contitute three types 1) customer 2)visitor c) admins d) ordermanager
    -- c admin manages products on site
    -- d user can submit a buying request
    -- e ordermanager can view the customer and the order.
