<footer>
    <div class = "container footer">
        <small>copyrights &copy; stockpile.Inc 2017</small>
    </div>
</footer>
