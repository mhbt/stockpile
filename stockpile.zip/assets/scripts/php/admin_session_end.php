<?php setcookie('site_manager','', time() - 86400, '/');
    header('Location:../../../public/admin.php');
?>