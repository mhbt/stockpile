<section class = "jumbotron admin-jumbotron text-center">
 <?php
    include_once "../assets/scripts/php/add_description_form.php";
    ?>
</section>
