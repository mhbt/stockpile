<?php setcookie('username','', time() - 86400, '/');
    header('Location:../../../public/index.php');
?>