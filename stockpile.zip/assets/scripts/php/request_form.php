<form class = "text-center form-horizontal form-inline" method = "post" action = "request_product.php">
<div class ="input-group">
    <label>Product Name :</label><input name = "product" class = "form-control" type = "text" max = 30 required>
</div>
<div class ="input-group">
    <label>Manufacturer :</label><input  name = "manufacturer" class = "form-control" type = "text" max = 30 required>
</div>
<div class ="input-group">
    <label>Quantity :</label><input name = "quantity" class = "form-control" type = "number">
</div>
<div class ="input-group">
    <button name = "submit" class = "form-controlform-input btn btn-warning btn-request" type = "submit">Request</button>
</div>
</form>